package de.jreality.geometry;

public enum FrameFieldType {
		PARALLEL,
		FRENET
}
