package de.jreality.jogl;

/**
 * A class introduced to maintain backward compatibility, now that
 * de.jreality.jogl.Viewer has been rename de.jreality.jogl.JOGLViewer.
 * 
 * @author gunn
 * 
 */
public class Viewer extends JOGLViewer {

}
