package de.jreality.jogl.shader;

public class EuclideanGLSLShader extends StandardGLSLShader {
	static String shaderLocation = "de/jreality/jogl/shader/resources/euclidean.vert";

	@Override
	String getShaderLocation() {
		// TODO Auto-generated method stub
		return shaderLocation;
	}

}
