package de.jreality.shader;

public interface GlslPolygonShader extends PolygonShader {

}
