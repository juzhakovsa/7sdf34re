package de.jreality.jogl3.geom;

public class Label {
	public String text;
	public double[] position;
}
