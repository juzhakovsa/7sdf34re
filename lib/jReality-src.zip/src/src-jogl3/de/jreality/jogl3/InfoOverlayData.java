package de.jreality.jogl3;

public class InfoOverlayData {
	
	public InfoOverlayData(){
		activated = false;
	}
	
	public boolean activated;
	public double framerate;
	public double clockrate;
	public int polygoncount;
}
