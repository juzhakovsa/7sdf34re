package de.jreality.jogl3;

import de.jreality.scene.SceneGraphNode;
import de.jreality.scene.proxy.tree.SceneTreeNode;

public class JOGLAppearanceInstance extends SceneTreeNode{

	protected JOGLAppearanceInstance(SceneGraphNode node) {
		super(node);
		// TODO Auto-generated constructor stub
	}
	
	public void updateData(){
//		System.out.println("updateAppearanceInstance");
		
	}

}
