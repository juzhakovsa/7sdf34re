package de.jreality.jogl3;

import de.jreality.scene.SceneGraphComponent;
import de.jreality.scene.proxy.tree.SceneGraphNodeEntity;

public class JOGLSceneGraphComponentEntity extends SceneGraphNodeEntity {

	protected JOGLSceneGraphComponentEntity(SceneGraphComponent node) {
		super(node);
	}
	
}
